
import 'package:flutter/material.dart';

void main() {
  runApp(const ExamApp());
}

class ExamApp extends StatelessWidget {
  const ExamApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Ulangan Siswa',
      home: ExamHome(),
    );
  }
}

class ExamHome extends StatelessWidget {
  final questions = [
    {'q': 'Ibu kota Indonesia?', 'a': 'Jakarta'},
    {'q': 'Hasil 7 × 8?', 'a': '56'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Ulangan Sederhana')),
      body: ListView.builder(
        itemCount: questions.length,
        itemBuilder: (context, i) {
          return ListTile(
            title: Text(questions[i]['q']!),
            onTap: () {
              showDialog(
                context: context,
                builder: (_) => AlertDialog(
                  title: Text(questions[i]['q']!),
                  content: Text("Jawaban: ${questions[i]['a']}"),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
